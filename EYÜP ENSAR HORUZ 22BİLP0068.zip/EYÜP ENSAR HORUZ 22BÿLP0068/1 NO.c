#include <stdio.h> 
 
int main(){ 
 
printf("C Programlama Dunyas�na Hosgeldiniz");  /*BURAYA EKRANA GELECEK OLAN �IKTIYI YAZARIZ */
return 0; 
 
}
